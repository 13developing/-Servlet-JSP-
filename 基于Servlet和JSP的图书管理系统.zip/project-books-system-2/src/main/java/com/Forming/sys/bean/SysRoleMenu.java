package com.Forming.sys.bean;

import lombok.Data;

@Data
public class SysRoleMenu {
    private Integer id;
    private Integer roleId;
    private Integer menuId;

}
