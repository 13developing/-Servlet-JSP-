package com.Forming.sys.utils;

/*这是我们当前项目会用到的常量*/
public class Constant {
    //文件上传的默认路径
    public static final String UPLOAD_DIRECTORY = "d:\\bookFile";
    public static final String LIST_PAGE_UTILS = "pageUtils";
    public static final String BASE_ACTION_LIST = "list";
    public static final String BASE_ACTION_SAVEORUPDATE = "saveOrUpdate";
    public static final String BASE_ACTION_FINDBYID = "findById";
    public static final String BASE_ACTION_REMOVE = "remove";
    public static final String BASE_ACTION_SAVEORUPDATEPAGE = "saveOrUpdatePage";
    public static final String UPDATE_ENTITY = "entity";
    public static final String LOGIN_USER = "loginUser";
    public static final String LOGIN_MENUS = "loginMenus";


}
